import{l as s,a}from"../chunks/DJTBi-tA.js";export{s as load_css,a as start};
