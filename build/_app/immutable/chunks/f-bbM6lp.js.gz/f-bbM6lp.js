import{m}from"./BcHN-y2m.js";m();
